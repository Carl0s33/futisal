package futsal;
import java.util.ArrayList;

public class TimeFutsal {
    String nome;
    ArrayList<JogadorFutsal> jogadores;
    TecnicoFutsal tecnico;
    Estatisticas estatisticas;

    public TimeFutsal(String nome) {
        this.nome = nome;
        this.jogadores = new ArrayList<>();
        this.estatisticas = new Estatisticas();
    }

    public String getNome() {
        return this.nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public ArrayList<JogadorFutsal> getJogadores() {
        return this.jogadores;
    }

    public void setJogadores(ArrayList<JogadorFutsal> jogadores) {
        this.jogadores = jogadores;
    }

    public TecnicoFutsal getTecnico() {
        return this.tecnico;
    }

    public void setTecnico(TecnicoFutsal tecnico) {
        this.tecnico = tecnico;
    }

    public Estatisticas getEstatisticas() {
        return this.estatisticas;
    }

    public void setEstatisticas(Estatisticas estatisticas) {
        this.estatisticas = estatisticas;
    }

    public void adicionarJogador(JogadorFutsal jogador) {
        this.jogadores.add(jogador);
    }

    public void removerJogador(JogadorFutsal jogador) {
        this.jogadores.remove(jogador);
    }

    public int quantidadeJogadores() {
        return this.jogadores.size();
    }

    public void contratarTecnico(TecnicoFutsal tecnico) {
        if (this.tecnico == null) {
            this.tecnico = tecnico;
        } else {
            System.out.println("O time já possui um técnico.");
        }
    }


    void contratarJogador(JogadorFutsal jogador) {
        if (this.jogadores.size() < 5) {
            this.jogadores.add(jogador);
        } else {
            System.out.println("O time já possui o número máximo de jogadores.");
        }
    }

    public void gerarTimeRandom() {
        String[] nomes = {"João", "Pedro", "Maria", "José", "Ana", "Carlos", "Luiza", "Paulo", "Sofia", "Rafael"};
        int numero = 1;

        for (PosicaoFutsal posicao : PosicaoFutsal.posicoesTime()) {
            if (posicao != PosicaoFutsal.TECNICO) {
                String nome = nomes[(int) (Math.random() * nomes.length)];
                int idade = (int) (Math.random() * (35 - 18 + 1) + 18);
                JogadorFutsal jogador = new JogadorFutsal(nome, idade, posicao);
                jogador.setNumero(numero++);
                this.contratarJogador(jogador);
            }
        }

        String nomeTecnico = nomes[(int) (Math.random() * nomes.length)];
        int idadeTecnico = (int) (Math.random() * (60 - 25 + 1) + 25);
        TecnicoFutsal tecnico = new TecnicoFutsal(nomeTecnico, idadeTecnico);
        tecnico.setEspecialidade(Especialidade.geraEspecialidade());
        tecnico.setPontosEspecialidade((int) (Math.random() * (5 - 1 + 1) + 1));
        this.contratarTecnico(tecnico);
    }

    
    void registrarVitoria() {
        this.estatisticas.incrementaVitorias();
    }

    void registrarDerrota() {
        this.estatisticas.incrementaDerrotas();
    }

    void registrarEmpate() {
        this.estatisticas.incrementaEmpates();
    }

    void incrementaGolsMarcados(int golsMarcados) {
        this.estatisticas.incrementaGolsMarcados(golsMarcados);
    }

    void incrementaGolsSofridos(int golsSofridos) {
        this.estatisticas.incrementaGolsSofridos(golsSofridos);
    }

    public int pontosAtaque() {
        int pontosAtaque = 0;
        for (JogadorFutsal jogador : this.jogadores) {
            pontosAtaque += jogador.getPontos_Ataque();
        }
        if (this.tecnico != null && this.tecnico.getEspecialidade() == Especialidade.OFENSIVA) {
            pontosAtaque += this.tecnico.getPontosEspecialidade();
        }
        return pontosAtaque;
    }

    public int pontosDefesa() {
        int pontosDefesa = 0;
        for (JogadorFutsal jogador : this.jogadores) {
            pontosDefesa += jogador.getPontos_Defesa();
        }
        if (this.tecnico != null && this.tecnico.getEspecialidade() == Especialidade.DEFENSIVA) {
            pontosDefesa += this.tecnico.getPontosEspecialidade();
        }
        return pontosDefesa;
    }
    
    public JogadorFutsal registrarGol() {
        int[] pontosAcumulados = new int[this.jogadores.size()];
        int pontosAtaque = this.pontosAtaque();
        int somaPontos = 0;

        for (int i = 0; i < this.jogadores.size(); i++) {
            somaPontos += this.jogadores.get(i).getPontos_Ataque();
            pontosAcumulados[i] = somaPontos;
        }

        int indiceGoleador = this.goleador(pontosAtaque, pontosAcumulados);
        this.jogadores.get(indiceGoleador).registrarGol();
        return this.jogadores.get(indiceGoleador);
    }

    private int goleador(int pontosAtaque, int[] pontosAcumulados) {
        int valorAleatorio = (int) (Math.random() * pontosAtaque) + 1;
        for (int i = 0; i < pontosAcumulados.length; i++) {
            if (pontosAcumulados[i] >= valorAleatorio) {
                return i;
            }
        }
        return 0; 
    }


    public void exibirTime(){
        System.out.println("Nome do Time: " + this.nome);
        //System.out.println("Titulos: " + this.titulos);
        System.out.println("Tecnico: " + this.tecnico);
        System.out.println("Jogadores" + this.jogadores);

    }

    public void exibirJogadores(){
        System.out.println("Jogadores do Time: " + this.nome);
        for(JogadorFutsal jogador: this.jogadores){
            System.out.println(jogador.getNome());
        }
    }

    public void exibirJogador(int numeroCamisa) {
        for (JogadorFutsal jogador : this.jogadores) {
            if (jogador.getNumero() == numeroCamisa) {
                jogador.exibirPerfil();
                return;
            }
        }
        System.out.println("Jogador não encontrado.");
    }

    public void exibirEstatisticas(){
        this.estatisticas.exibirEstatisticas();
    }

    public void exibirEstatisticasLinha() {
        System.out.println(this.nome + ": " + this.estatisticas.toString() + ", Saldo de Gols: " + this.estatisticas.saldoGols());
    }

}
