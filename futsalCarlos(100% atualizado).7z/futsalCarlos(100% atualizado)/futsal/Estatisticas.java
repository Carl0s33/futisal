package futsal;

public class Estatisticas {
    private int titulos;
    private int jogos;
    private int pontos;
    private int vitorias;
    private int empates;
    private int derrotas;
    private int gols_Marcados;
    private int gols_Sofridos;

    

    /**
     * @return int return the titulos
     */
    public int getTitulos() {
        return this.titulos;
    }

    /**
     * @param titulos the titulos to set
     */
    public void setTitulos(int titulos) {
        this.titulos = titulos;
    }

    /**
     * @return int return the jogos
     */
    public int getJogos() {
        return this.jogos;
    }

    /**
     * @param jogos the jogos to set
     */
    public void setJogos(int jogos) {
        this.jogos = jogos;
    }

    /**
     * @return int return the pontos
     */
    public int getPontos() {
        return this.pontos;
    }

    /**
     * @param pontos the pontos to set
     */
    public void setPontos(int pontos) {
        this.pontos = pontos;
    }

    /**
     * @return int return the vitorias
     */
    public int getVitorias() {
        return this.vitorias;
    }

    /**
     * @param vitorias the vitorias to set
     */
    public void setVitorias(int vitorias) {
        this.vitorias = vitorias;
    }

    /**
     * @return int return the empates
     */
    public int getEmpates() {
        return this.empates;
    }

    /**
     * @param empates the empates to set
     */
    public void setEmpates(int empates) {
        this.empates = empates;
    }

    /**
     * @return int return the derrotas
     */
    public int getDerrotas() {
        return this.derrotas;
    }

    /**
     * @param derrotas the derrotas to set
     */
    public void setDerrotas(int derrotas) {
        this.derrotas = derrotas;
    }

    /**
     * @return int return the golsMarcados
     */
    public int getGols_Marcados() {
        return this.gols_Marcados;
    }

    /**
     * @param golsMarcados the golsMarcados to set
     */
    public void setGols_Marcados(int golsMarcados) {
        this.gols_Marcados = golsMarcados;
    }

    /**
     * @return int return the golsSofridos
     */
    public int getGols_Sofridos() {
        return this.gols_Sofridos;
    }

    /**
     * @param golsSofridos the golsSofridos to set
     */
    public void setGols_Sofridos(int golsSofridos) {
        this.gols_Sofridos = golsSofridos;
    }

    public void reiniciarEstatisticas(){
        this.jogos = 0;
        this.pontos = 0;
        this.vitorias = 0;
        this.empates = 0;
        this.derrotas = 0;
        this.gols_Marcados = 0;
        this.gols_Sofridos = 0;
    }
    
    public void incrementaTitulos() {
        this.titulos++;
    }

    public void incrementaGolsMarcados(int golsMarcados) {
        if (golsMarcados >= 0) {
            this.gols_Marcados += golsMarcados;
        } else {
            System.err.println("Erro: Número de gols marcados inválido.");
        }
    }

    public void incrementaGolsSofridos(int golsSofridos) {
        if (golsSofridos >= 0) {
            this.gols_Sofridos += golsSofridos;
        } else {
            System.err.println("Erro: Número de gols sofridos inválido.");
        }
    }

    public void incrementaVitorias() {
        this.vitorias++;
        this.pontos += 3; 
        this.jogos++;
    }

    public void incrementaEmpates() {
        this.empates++;
        this.pontos++; 
        this.jogos++;
    }

    public void incrementaDerrotas() {
        this.derrotas++;
        this.jogos++;
    }

    public void incrementaPontos(int pontos) {
        if (pontos >= 0) {
            this.pontos += pontos;
        } else {
            System.err.println("Erro: Número de pontos inválido.");
        }
    }

    public int saldoGols() {
        return this.gols_Marcados - this.gols_Sofridos;
    }

    public void exibirEstatisticas() {
        System.out.println("Jogos: " + this.jogos);
        System.out.println("Pontos: " + this.pontos);
        System.out.println("Vitórias: " + this.vitorias);
        System.out.println("Empates: " + this.empates);
        System.out.println("Derrotas: " + this.derrotas);
        System.out.println("Gols Marcados: " + this.gols_Marcados);
        System.out.println("Gols Sofridos: " + this.gols_Sofridos);
        System.out.println("Saldo de Gols: " + saldoGols());
    }

    public String toString() {
        return "Pontos: " + this.pontos +
                ", Jogos: " + this.jogos +
                ", Vitórias: " + this.vitorias +
                ", Empates: " + this.empates +
                ", Derrotas: " + this.derrotas +
                ", Gols Marcados: " + this.gols_Marcados +
                ", Gols Sofridos: " + this.gols_Sofridos +
                ", Saldo de Gols: " + saldoGols();
    }

   

}
