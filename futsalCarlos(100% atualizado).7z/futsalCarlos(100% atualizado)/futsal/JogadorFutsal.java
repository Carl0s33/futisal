package futsal;

public class JogadorFutsal {

    private String nome;
    private int idade;
    private int numero;
    private int gols_Totais;
    private int gols_Campeonato;
    private int pontos_Ataque;
    private int pontos_Defesa;
    private PosicaoFutsal posicao;
    private static int n_Jogadores = 0;

    

    public JogadorFutsal(String nome, int idade, PosicaoFutsal posicao) {
        this.nome = nome;
        this.idade = idade;
        this.posicao = posicao;
        this.gols_Totais = 0;
        this.gols_Campeonato = 0;
        this.numero = 0;
        gerarPontos();
        n_Jogadores++;
    }

    public void gerarPontos() {
       
        int pontosAtaque;
        int pontosDefesa;

        if (this.posicao == PosicaoFutsal.GOLEIRO) {
            pontosAtaque = (int) (Math.random() * (4 - 1 + 1) + 1);
            pontosDefesa = (int) (Math.random() * (15 - 10 + 1) + 10);
        } else if (this.posicao == PosicaoFutsal.FIXO || this.posicao == PosicaoFutsal.PIVO) {
            pontosAtaque = (int) (Math.random() * (8 - 5 + 1) + 5);
            pontosDefesa = (int) (Math.random() * (12 - 8 + 1) + 8);
        } else {
            pontosAtaque = (int) (Math.random() * (12 - 9 + 1) + 9);
            pontosDefesa = (int) (Math.random() * (7 - 3 + 1) + 3);
        }
        this.pontos_Ataque = pontosAtaque;
        this.pontos_Defesa = pontosDefesa;
    }

    public void registrarGol() {
        this.gols_Totais++;
        this.gols_Campeonato++;
    }

    public void reiniciarGolsCampeonato() {
        this.gols_Campeonato = 0;
    }

    public void exibirPerfil(){
        System.out.println("Nome: " + this.nome);
        System.out.println("Idade: " + this.idade);
        System.out.println("Número: " + this.numero);
        System.out.println("Gols Totais: " + this.gols_Totais);
        System.out.println("Gols Campeonato: " + this.gols_Campeonato);
        System.out.println("Pontos de Ataque: " + this.pontos_Ataque);
        System.out.println("Pontos de Defesa: " + this.pontos_Defesa);
        System.out.println("Posição: " + this.posicao);
    }

    /**
     * @return String return the nome
     */
    public String getNome() {
        return this.nome;
    }

    /**
     * @param nome the nome to set
     */
    public void setNome(String nome) {
        this.nome = nome;
    }

    /**
     * @return int return the idade
     */
    public int getIdade() {
        return this.idade;
    }

    /**
     * @param idade the idade to set
     */
    public void setIdade(int idade) {
        if (idade >= 18) { 
            this.idade = idade;
        } else {
            System.err.println("Erro: Idade inválida para um jogador de futsal.");
        }
    }

    /**
     * @return int return the numero
     */
    public int getNumero() {
        return this.numero;
    }

    /**
     * @param numero the numero to set
     */
    public void setNumero(int numero) {
        if (numero >= 1 && numero <= 20) { 
            this.numero = numero;
        } else {
            System.err.println("Erro: Número de camisa inválido.");
        }
    }

    /**
     * @return int return the gols_Totais
     */
    public int getGols_Totais() {
        return this.gols_Totais;
    }

    /**
     * @param gols_Totais the gols_Totais to set
     */
    public void setGols_Totais(int gols_Totais) {
        this.gols_Totais = gols_Totais;
    }

    /**
     * @return int return the gols_Campeonato
     */
    public int getGols_Campeonato() {
        return this.gols_Campeonato;
    }

    /**
     * @param gols_Campeonato the gols_Campeonato to set
     */
    public void setGols_Campeonato(int gols_Campeonato) {
        this.gols_Campeonato = gols_Campeonato;
    }

    /**
     * @return int return the pontos_Ataque
     */
    public int getPontos_Ataque() {
        return this.pontos_Ataque;
    }

    /**
     * @param pontos_Ataque the pontos_Ataque to set
     */
    public void setPontos_Ataque(int pontos_Ataque) {
        this.pontos_Ataque = pontos_Ataque;
    }

    /**
     * @return int return the pontos_Defesa
     */
    public int getPontos_Defesa() {
        return this.pontos_Defesa;
    }

    /**
     * @param pontos_Defesa the pontos_Defesa to set
     */
    public void setPontos_Defesa(int pontos_Defesa) {
        this.pontos_Defesa = pontos_Defesa;
    }

    /**
     * @return PosicaoFutsal return the posicao
     */
    public PosicaoFutsal getPosicao() {
        return this.posicao;
    }

    /**
     * @param posicao the posicao to set
     */
    public void setPosicao(PosicaoFutsal posicao) {
        this.posicao = posicao;
    }
    
    public static int getn_Jogadores() {
        return n_Jogadores;
    }
}
