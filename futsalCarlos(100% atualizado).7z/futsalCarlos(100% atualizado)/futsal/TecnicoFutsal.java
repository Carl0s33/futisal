package futsal;

public class TecnicoFutsal {
    private String nome;
    private int idade;
    private PosicaoFutsal posicao;
    private Especialidade especialidade;
    private int pontosEspecialidade;

    public static final int TECNICO_IDADE_MINIMA = 25;
    public static final int TECNICO_ESPECIALIDADE_MAXIMA = 5;

    public TecnicoFutsal(String nome, int idade) {
        this.nome = nome;
        this.idade = idade;
        this.posicao = PosicaoFutsal.TECNICO;
    }

   

    public void exibirPerfil(){
        System.out.println("Nome: " + this.nome);
        System.out.println("Idade: " + this.idade);
        System.out.println("Posição: " + this.posicao);
        System.out.println("Especialidade: " + this.especialidade);
        System.out.println("Pontos de Especialidade: " + this.pontosEspecialidade);
    }



    /**
     * @return String return the nome
     */
    public String getNome() {
        return this.nome;
    }

    /**
     * @param nome the nome to set
     */
    public void setNome(String nome) {
        this.nome = nome;
    }

    /**
     * @return int return the idade
     */
    public int getIdade() {
        return this.idade;
    }

    /**
     * @param idade the idade to set
     */
    public void setIdade(int idade) {
        if (idade >= 25) {
            this.idade = idade;
        } else {
            System.err.println("Erro: Idade inválida para um técnico.");
        }
    }

    /**
     * @return PosicaoFutsal return the posicao
     */
    public PosicaoFutsal getPosicao() {
        return this.posicao;
    }

    /**
     * @param posicao the posicao to set
     */
    public void setPosicao(PosicaoFutsal posicao) {
        this.posicao = posicao;
    }

    /**
     * @return Especialidade return the especialidade
     */
    public Especialidade getEspecialidade() {
        return this.especialidade;
    }

    /**
     * @param especialidade the especialidade to set
     */
    public void setEspecialidade(Especialidade especialidade) {
        this.especialidade = especialidade;
    }

    /**
     * @return int return the pontosEspecialidade
     */
    public int getPontosEspecialidade() {
        return this.pontosEspecialidade;
    }

    /**
     * @param pontosEspecialidade the pontosEspecialidade to set
     */
    public void setPontosEspecialidade(int pontosEspecialidade) {
        if (pontosEspecialidade >= 1 && pontosEspecialidade <= 5) {
            this.pontosEspecialidade = pontosEspecialidade;
        } else {
            System.err.println("Erro: Pontos de especialidade inválidos."); 
        }
    }

}
