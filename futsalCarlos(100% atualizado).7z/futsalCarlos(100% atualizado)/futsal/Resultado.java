package futsal;

public class Resultado {
    private int golsA;
    private int golsB;

    public int getGolsA() {
        return golsA;
    }

    public void incrementaGolsA() {
        this.golsA++;
    }

    public int getGolsB() {
        return golsB;
    }

    public void incrementaGolsB() {
        this.golsB++;
    }
}
