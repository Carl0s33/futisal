import java.util.Random;

public class JogadorFutsal {
    private String nome;
    private int idade;
    private int numero;
    private int gols_totais;
    private int gols_campeonato;
    private int pontos_ataque;
    private int pontos_defesa;
    private PosicaoFutsal posicao;
    private int n_jogadores;

    JogadorFutsal(String nome, int idade, PosicaoFutsal posicao) {
        this.nome = nome;
        this.idade = idade;
        this.posicao = posicao;
        this.numero = 0;
        this.gols_totais = 0;
        this.gols_campeonato = 0;
        this.pontos_ataque = 0;
        this.pontos_defesa = 0;
        this.n_jogadores = 0;
        gerarPontos();

    }

    private void gerarPontos() {
        Random random = new Random();
        if (this.posicao == PosicaoFutsal.GOLEIRO) {
            this.pontos_ataque = random.nextInt(4) + 1;
            this.pontos_defesa = random.nextInt(6) + 10;
        } else {
            this.pontos_ataque = random.nextInt(15) + 1;
            this.pontos_defesa = random.nextInt(15) + 1;
        }
    }

    public void registrarGol() {
        this.gols_totais++;
        this.gols_campeonato++;
    }

    public void reiniciarGolsCampeonato() {
        this.gols_campeonato = 0;
    }
    public int getGolsCampeonato(){
        return gols_campeonato;
}

    public String getNome() {
        return nome;
    }

    public int getIdade() {
        return idade;
    }

    public void setIdade(int idade){
        if (idade < 18) {
            System.out.println("A idade deve ser maior ou igual a 18 anos.");
            return;
        }
        this.idade = idade;
    }
    public PosicaoFutsal getPosicao() {
        return posicao;
    }
    public void setPosicao(PosicaoFutsal posicao) {
        this.posicao = posicao;
    }

    public int getNumero() {
        return numero;
    }
    public void setNumero(int numero) {
        if (numero < 1 && numero > 20) {
            System.out.println("O número deve estar entre 1 e 20.");
            return;
        }
        else{
                this.numero = numero;
        }
    
    }
    public int getGolsTotais() {
        return gols_totais;
    }
    public int setGolsTotais(int gols_totais) {
        if(gols_totais < 0){
        System.out.println("Não é possível ter menos de zero gols totais.");
       }
       else{
       }
        this.gols_totais = gols_totais;
        return this.gols_totais;
    }

    public int getPontosAtaque() {
        return pontos_ataque;
    }
    public int setPontosAtaque(int pontos_ataque) {
        if(pontos_ataque < 1 && pontos_ataque > 15){
        System.out.println("Não é possível ter menos de 0 ou maior que 15 pontos de ataque.");
       }
       else{
       }
        this.pontos_ataque = pontos_ataque;
        return this.pontos_ataque;
    }


    public int getPontosDefesa() {
        return pontos_defesa;
    }
    public int setPontosDefesa(int pontos_defesa) {
        if(pontos_defesa < 1 && pontos_defesa > 15)
        System.out.println( "Não é possível ter menos de 0 ou maior que 15 pontos de defesa.");
       else{
       }
        this.pontos_defesa = pontos_defesa;
        return this.pontos_defesa;
    }

    public int getN_jogadores() {
        return n_jogadores;
    }

    public void setN_jogadores(int n_jogadores) {
        if (n_jogadores < 0 && n_jogadores > 12) {
            System.out.println("O número de jogadores deve estar entre 0 e 12.");
            return;
            
        }
        else{

        }
        this.n_jogadores = n_jogadores;
    }

   
}

