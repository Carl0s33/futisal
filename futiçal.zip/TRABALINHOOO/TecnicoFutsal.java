
public class TecnicoFutsal {
    // Atributos da classe
    private String nome;
    private int idade;


    // Construtor
    public TecnicoFutsal(String nome, int idade) {
        this.nome = nome;
        this.idade = idade;
    }
   

    // Setters
    public void setNome(String nome) {
        this.nome = nome;
    }


    public String getNome() {
        return nome;
    }

    public int getIdade() {
        return idade;
    }
    public void setIdade(int idade) {
        if (idade < 25) {
            System.out.println("A idade deve ser maior ou igual a 25 anos.");
            return;
        }
        
        this.idade = idade;
    }


 //exibicao das informacoes

 public void exibirInformacoes() {
    System.out.println("Nome: " + nome);
    System.out.println("Idade: " + idade);
 }
}

