public class Estatisticas {
    private int titulos;
    private int jogos;
    private int pontos;
    private int vitorias;
    private int empates;
    private int derrotas;
    private int golsMarcados;
    private int golsSofridos;
    private int saldoGols;

    // Construtor
    public Estatisticas() {
        this.titulos = 0;
        this.jogos = 0;
        this.pontos = 0;
        this.vitorias = 0;
        this.empates = 0;
        this.derrotas = 0;
        this.golsMarcados = 0;
        this.golsSofridos = 0;
        this.saldoGols = 0;
    }

    // Método para reiniciar as estatísticas
    public void reiniciarEstatisticas() {
        this.titulos = 0;
        this.jogos = 0;
        this.pontos = 0;
        this.vitorias = 0;
        this.empates = 0;
        this.derrotas = 0;
        this.golsMarcados = 0;
        this.golsSofridos = 0;
        this.saldoGols = 0;
    }

    // Métodos para incrementar valores
    public void incrementaTitulos(int titulos) {
        this.titulos += titulos;
    }

    public void incrementaGolsMarcados(int golsMarcados) {
        this.golsMarcados += golsMarcados;
    }

    public void incrementaGolsSofridos(int golsSofridos) {
        this.golsSofridos += golsSofridos;
    }

    public void incrementaVitorias(int vitorias) {
        this.vitorias = this.vitorias + vitorias;
        this.pontos = this.pontos + (vitorias * 3);
    }

    public void incrementaEmpates(int empates) {
        this.empates = this.empates + empates;
        this.pontos = this.pontos + empates;
    }

    public void incrementaDerrotas(int derrotas) {
        this.derrotas = this.derrotas + derrotas;
    }

    public void incrementaPontos(int pontos) {
        this.pontos += pontos;
    }

    public void incrementaJogos(int jogos) {
        this.jogos += jogos;
    }

    // Método para calcular o saldo de gols
    public void calculaSaldoGols() {
        this.saldoGols = this.golsMarcados - this.golsSofridos;
    }


    public int getTitulos() {
        return this.titulos;
    }

    public int setTitulos(int titulos) {
       if(titulos < 0){
        System.out.println("Não é possível ter menos de zero títulos.");
     
       }
       else{
    
       }
        this.titulos = titulos;
        return this.titulos;
     
    }
    public int getgolsMarcados() {
        return this.golsMarcados;
    }
    
    public int setGolsMarcados(int golsMarcados) {
        if(golsMarcados < 0){
        System.out.println("Não é possível ter menos de zero gols marcados.");
       }
       else{
    
       }
        this.golsMarcados = golsMarcados;
        return this.golsMarcados;
    }



    public int getGolsSofridos() {
        return this.golsSofridos;
    }
    
    public int setGolsSofridos(int golsSofridos) {
        if(golsSofridos < 0){
        System.out.println("Não é possível ter menos de zero gols sofridos.");
       }
       else{
    
       }
        this.golsSofridos = golsSofridos;
        return this.golsSofridos;
    }
     public int getPontos() {
        return this.pontos;
    }
    
    public int setPontos(int pontos) {
        if(pontos < 0 ){
        System.out.println("Não é possível ter menos de zero pontos.");
       }
       else{
    
       }
        this.pontos = pontos;
        return this.pontos;
    }
    public int getJogos() {
        return this.jogos;
    }
    
    public int setJogos(int jogos) {
        if(jogos < 0){
        System.out.println("Não é possível ter menos de zero jogos.");
       }
       else{
    
       }
        this.jogos = jogos;
        return this.jogos;
        }


        public int getVitorias() {
        return this.vitorias;
    }
    
    public int setVitorias(int vitorias) {
        if(vitorias < 0){
        System.out.println("Não é possível ter menos de zero vitórias.");
       }
       else{
       }
        this.vitorias = vitorias;
        return this.vitorias;
    }
    public int getEmpates() {
        return this.empates;
    }
    
    public int setEmpates(int empates) {
        if(empates < 0){
        System.out.println("Não é possível ter menos de zero empates.");
       }
       else{
       }
        this.empates = empates;
        return this.empates;
    }

    public int getDerrotas() {
        return this.derrotas;
    }
    
    public int setDerrotas(int derrotas) {
        if(derrotas < 0){
        System.out.println("Não é possível ter menos de zero derrotas.");
       }
       else{
       }
        this.derrotas = derrotas;
        return this.derrotas;
    }










    // Método para exibir as estatísticas no console
    public void exibeEstatisticas() {
        calculaSaldoGols(); 
        System.out.println("Títulos: " + this.titulos);
        System.out.println("Jogos: " + this.jogos);
        System.out.println("Pontos: " + this.pontos);
        System.out.println("Vitórias: " + this.vitorias);
        System.out.println("Empates: " + this.empates);
        System.out.println("Derrotas: " + this.derrotas);
        System.out.println("Gols marcados: " + this.golsMarcados);
        System.out.println("Gols sofridos: " + this.golsSofridos);
        System.out.println("Saldo de gols: " + this.saldoGols);
    }

    // Método toString para representação em texto
    public String toString() {
        calculaSaldoGols(); // Garante que o saldo esteja atualizado
        return "Títulos: " + this.titulos + ", Jogos: " + this.jogos + ", Pontos: " + this.pontos + 
               ", Vitórias: " + this.vitorias + ", Empates: " + this.empates + ", Derrotas: " + this.derrotas + 
               ", Gols Marcados: " + this.golsMarcados + ", Gols Sofridos: " + this.golsSofridos + 
               ", Saldo de Gols: " + this.saldoGols;
    }


}
 