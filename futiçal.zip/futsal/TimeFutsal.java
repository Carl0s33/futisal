
import java.util.ArrayList;
public class TimeFutsal {
    private String nome;
    private TecnicoFutsal tecnico;
    private ArrayList<JogadorFutsal> jogadores;



    TimeFutsal(String nomeTime){
        this.nome = nomeTime;
        jogadores = new ArrayList<JogadorFutsal>();
    }
    
    public void contratarTecnico(TecnicoFutsal tecnico){
        if (this.tecnico != null) {
            System.out.println("Time já possui um técnico.");
        } else {
            this.tecnico = tecnico;
        }
    }

    public void contratarJogador(JogadorFutsal jogador){
        if(jogadores.size()<5){
            this.jogadores.add(jogador);
        }else{
            System.out.println("Limite de jogadores atingido");
        }
    }
    public void gerarTimeRadom(ArrayList<JogadorFutsal> jogadores){
        
    }

}

    

