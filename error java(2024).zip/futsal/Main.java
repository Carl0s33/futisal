public class Main {
    public static void main(String[] args) {
      
        TimeFutsal time = new TimeFutsal("Ibis FC");
        JogadorFutsal jogador1 = new JogadorFutsal(
                "Manel Gomi", 25, PosicaoFutsal.PIVO);
        JogadorFutsal jogador2 = new JogadorFutsal(
                "Thais Carla", 22, PosicaoFutsal.GOLEIRO);
        JogadorFutsal jogador3 = new JogadorFutsal(
                "Oreia Seca", 28, PosicaoFutsal.ALA);
        JogadorFutsal jogador4 = new JogadorFutsal(
                "João zap", 23, PosicaoFutsal.FIXO);
        JogadorFutsal jogador5 = new JogadorFutsal(
                "Luva de pedreiro", 30, PosicaoFutsal.ALA);

        // Contratando jogadores
        time.contratarJogador(jogador1);
        time.contratarJogador(jogador2);
        time.contratarJogador(jogador3);
        time.contratarJogador(jogador4);
        time.contratarJogador(jogador5);

        // Criando e contratando um técnico
        TecnicoFutsal tecnico = new TecnicoFutsal("Pep Guardiola", 35);
        tecnico.getEspecialidade(Especialidade.OFENSIVA);
        tecnico.setPontosEspecialidade(10);
        time.contratarTecnico(tecnico);

        // Registrando gols
        jogador1.registrarGol();
        jogador1.registrarGol();
        jogador3.registrarGol();

        // Exibindo as informações do time
        time.exibeTime();
        time.exibeEstatisticas();

        // Exibindo a pontuação do time no ataque e defesa
        System.out.println("\nPontos no ataque: " + time.pontosAtaque());
        System.out.println("Pontos na defesa: " + time.pontosDefesa());
    }
}
