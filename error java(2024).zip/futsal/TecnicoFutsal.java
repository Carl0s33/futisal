
public class TecnicoFutsal {
    // Atributos da classe
    private String nome;
    private int idade;
    private PosicaoFutsal posicao;
    private int pontosEspecialidade;
    private Especialidade especialidade;

    // Construtor
    public TecnicoFutsal(String nome, int idade) {
        this.nome = nome;
        this.idade = idade;
    }
   

    // Setters
    public void setNome(String nome) {
        this.nome = nome;
    }


    public String getNome() {
        return nome;
    }

    public int getIdade() {
        return idade;
    }
    public void setIdade(int idade) {
        if (idade < 25) {
            System.out.println("A idade deve ser maior ou igual a 25 anos.");
            return;
        }
        
        this.idade = idade;
    }
    public PosicaoFutsal getPosicao() {
        return posicao;
    }
    public void setPosicao(PosicaoFutsal posicao) {
        this.posicao = posicao;
    }

    public int getPontosEspecialidade() {
        return pontosEspecialidade;
    }

    public void setPontosEspecialidade(int pontosEspecialidade) {
        this.pontosEspecialidade = pontosEspecialidade;
    }

    public void getEspecialidade(Especialidade especialidade){
        this.especialidade = especialidade;
    }
    public Especialidade getEspecialidade(){
        return especialidade;
    }


 //exibicao das informacoes

 public void exibirInformacoes() {
    System.out.println("Nome: " + nome);
    System.out.println("Idade: " + idade);
 }
}

