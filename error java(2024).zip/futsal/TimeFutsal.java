import java.util.ArrayList;

public class TimeFutsal {
    private String nome;
    private TecnicoFutsal tecnico;
    private Estatisticas estatisticas;
    private ArrayList<JogadorFutsal> jogadores;

    public TimeFutsal(String nomeTime) {
        this.nome = nomeTime;
        this.jogadores = new ArrayList<>();
        this.estatisticas = new Estatisticas();  // Instância para manipular estatísticas
    }

    public void contratarTecnico(TecnicoFutsal tecnico) {
        if (this.tecnico != null) {
            System.out.println("Time já possui um técnico.");
        } else {
            this.tecnico = tecnico;
        }
    }

    public void contratarJogador(JogadorFutsal jogador) {
        if (jogadores.size() < 5) {
            this.jogadores.add(jogador);
        } else {
            System.out.println("Limite de jogadores atingido.");
        }
    }

    public int pontosAtaque() {
        int pontosAtaque = 0;
        for (JogadorFutsal jogador : jogadores) {
            pontosAtaque += jogador.getPontosAtaque();
        }
        if (tecnico != null && tecnico.getEspecialidade() == Especialidade.OFENSIVA) {
            pontosAtaque += tecnico.getPontosEspecialidade();
        }
        return pontosAtaque;
    }

    public int pontosDefesa() {
        int pontosDefesa = 0;
        for (JogadorFutsal jogador : jogadores) {
            pontosDefesa += jogador.getPontosDefesa();
        }
        if (tecnico != null && tecnico.getEspecialidade() == Especialidade.DEFENSIVA) {
            pontosDefesa += tecnico.getPontosEspecialidade();
        }
        return pontosDefesa;
    }
    

    public void exibeTime() {
        System.out.println("Nome do time: " + this.nome);
        System.out.println("Quantidade de títulos: " + estatisticas.getTitulos());

        if (this.tecnico != null) {
            System.out.println("\nInformações do técnico:");
            this.tecnico.exibirInformacoes();
        }

        System.out.println("\nInformações dos jogadores:");
        for (JogadorFutsal jogador : jogadores) {
            jogador.exibirInformacoes();
        }
    }
 void exibeEstatisticas() {
        estatisticas.calculaSaldoGols();
        estatisticas.exibeEstatisticas();
    }

    @Override
    public String toString() {
        estatisticas.calculaSaldoGols();
        return "Time: " + this.nome + ", " + estatisticas.toString();
    }
}
